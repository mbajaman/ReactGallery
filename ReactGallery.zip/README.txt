The following README provides instructions on how to make sure the app runs.
Make sure you npm install in the project director prior to running the application.

To test the facebook functionality:
>Tap the Facebook icon.
>Log in
>Tap the placeholder
>Your profile picture should appear.